/// Returns a friendly hello-world string.
pub fn hello() -> &'static str {
    "hello world"
}
